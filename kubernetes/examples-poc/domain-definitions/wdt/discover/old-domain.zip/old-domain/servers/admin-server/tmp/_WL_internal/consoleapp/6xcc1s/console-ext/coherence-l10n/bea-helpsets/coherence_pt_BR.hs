<?xml version='1.0' encoding="UTF-8" ?>
<!DOCTYPE helpset   
PUBLIC "-//Sun Microsystems Inc.//DTD JavaHelp HelpSet Version 2.0//EN"
         "http://java.sun.com/products/javahelp/helpset_2_0.dtd">

<helpset xml:lang="pt-BR" version="2.0">

  <!-- title -->
  <title>Ajuda do WebLogic Server Administration Console Coherence</title>

  <!-- maps -->
  <maps>
     <homeID>intro</homeID>
     <mapref location="pt-br/coherence-map.jhm" />
  </maps>
 

  <!-- views -->
  <view>
    <name>TOC</name>
    <label>Sumário</label>
    <type>javax.help.TOCView</type>
    <data>pt-br/coherence-toc.xml</data>
  </view>

  <view>
    <name>Search</name>
    <label>Pesquisar</label>
    <type>javax.help.SearchView</type>
    <data engine="com.bea.help.ConsoleSearchEngine">pt-br/coherence-search</data>
  </view>
  

</helpset>

