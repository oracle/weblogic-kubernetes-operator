<?xml version='1.0' encoding="UTF-8" ?>
<!DOCTYPE helpset   
PUBLIC "-//Sun Microsystems Inc.//DTD JavaHelp HelpSet Version 2.0//EN"
         "http://java.sun.com/products/javahelp/helpset_2_0.dtd">

<helpset xml:lang="zh-TW" version="2.0">

  <!-- title -->
  <title>WebLogic Server 管理主控台 Coherence 說明</title>

  <!-- maps -->
  <maps>
     <homeID>intro</homeID>
     <mapref location="zh-tw/coherence-map.jhm" />
  </maps>
 

  <!-- views -->
  <view>
    <name>TOC</name>
    <label>目錄</label>
    <type>javax.help.TOCView</type>
    <data>zh-tw/coherence-toc.xml</data>
  </view>

  <view>
    <name>Search</name>
    <label>搜尋</label>
    <type>javax.help.SearchView</type>
    <data engine="com.bea.help.ConsoleSearchEngine">zh-tw/coherence-search</data>
  </view>
  

</helpset>

